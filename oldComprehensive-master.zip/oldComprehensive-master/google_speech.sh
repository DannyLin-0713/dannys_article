#!/bin/bash

command bash google_speech_getname.sh
command bash google_speech_chkstatus.sh
